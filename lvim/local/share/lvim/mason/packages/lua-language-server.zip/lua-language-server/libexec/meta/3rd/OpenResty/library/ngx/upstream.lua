---@meta
local upstream = {}
function upstream.get_backup_peers() end
function upstream.get_servers() end
function upstream.current_upstream_name() end
function upstream.get_primary_peers() end
function upstream.set_peer_down() end
function upstream.get_upstreams() end
return upstream
